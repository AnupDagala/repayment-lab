// Executes the actual dashboard script against a minimal DOM implementation.
// Checks rendered contents and filter behavior, not pixel layout or browser compatibility.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
class Element{constructor(){this.children=[];this.value='';this.textContent='';this.innerHTML='';this.events={}}append(x){this.children.push(x)}replaceChildren(...x){this.children=x}createTHead(){const x=new Element();this.head=x;return x}createTBody(){const x=new Element();this.body=x;return x}insertRow(){const x=new Element();this.children.push(x);return x}insertCell(){const x=new Element();this.children.push(x);return x}addEventListener(n,f){this.events[n]=f}}
const els={},document={createElement:()=>new Element(),getElementById:id=>els[id]??(els[id]=new Element())};
els.date=new Element();els.date.value='2026-09-30';els.segment=new Element();els.segment.value='All';
const source=fs.readFileSync('demo/index.html','utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
const ctx=vm.createContext({document});vm.runInContext(source,ctx);
let checks=0;for(const d of ['2026-07-31','2026-08-31','2026-09-30'])for(const s of ['All','Salaried','Self-employed','New-to-credit']){
els.date.value=d;els.segment.value=s;els.date.events.change();
assert(els.cards.innerHTML.includes(s==='All'?'<b>600</b>':'<b>200</b>'));
assert(els.quality.textContent.startsWith('PASS'));
assert(els.insight.textContent.includes(d));assert(els.insight.textContent.includes(s));
assert.equal(els.loans.children[0].body.children.length,20);
assert.equal(els.matrix.children[0].body.children.length,5);
assert.equal(els.cohorts.children[0].body.children.length,6);
assert(!els.cards.innerHTML.includes('NaN'));assert(els.bars.innerHTML.includes('<svg'));checks++;
}console.log(checks+' dashboard date/segment combinations passed (DOM harness; not real browser).');
