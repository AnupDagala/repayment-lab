import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
import lab

class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.c=lab.connect()
        self.c.execute("INSERT INTO loans VALUES('L','2026-01-01','Salaried',30000)")
        self.c.executemany('INSERT INTO installments VALUES(?,?,?,?)',[('I1','L','2026-02-01',10000),('I2','L','2026-03-01',10000),('I3','L','2026-04-01',10000)])
    def pay(self,pid,amount,day='2026-02-10',iid='I1'):
        self.c.execute('INSERT INTO payments VALUES(?,?,?,?)',(pid,iid,day,amount))
    def row(self,d='2026-03-03'):
        return lab.snapshot(self.c,d)[0]
    def test_hand_calculated_partial(self):
        self.pay('P1',4000);self.pay('P2',3000)
        x=self.row();self.assertEqual((x['due_paise'],x['collected_paise'],x['overdue_paise'],x['outstanding_paise'],x['dpd']),(20000,7000,13000,23000,30))
    def test_future_payment_no_leakage(self):
        self.pay('P',10000,'2026-04-01');self.assertEqual(self.row()['collected_paise'],0)
    def test_fully_paid_oldest_changes_dpd(self):
        self.pay('P',10000);self.assertEqual(self.row()['dpd'],2)
    def test_due_today_not_overdue(self):
        self.assertEqual(self.row('2026-02-01')['overdue_paise'],0)
    def test_not_originated_excluded(self):
        self.assertEqual(lab.snapshot(self.c,'2025-12-31'),[])
    def test_no_due_denominator(self):
        self.assertIsNone(lab.metrics(lab.snapshot(self.c,'2026-01-15'))['collection_pct'])
    def test_overpayment_flag_and_cap(self):
        self.pay('P',12000);x=self.row();self.assertEqual(x['collected_paise'],10000);self.assertEqual(x['excess_paise'],2000);self.assertFalse(lab.quality(self.c,'2026-03-03')['passed']);self.assertEqual(lab.quality(self.c,'2026-03-03')['reconciliation_delta_paise'],0)
    def test_reconciliation(self):
        self.pay('P',7000);self.assertTrue(lab.quality(self.c,'2026-03-03')['passed'])
    def test_duplicate_rejected(self):
        self.pay('P',5000)
        with self.assertRaises(sqlite3.IntegrityError):self.pay('P',5000)
    def test_orphan_rejected(self):
        with self.assertRaises(sqlite3.IntegrityError):self.pay('P',5000,iid='MISSING')
    def test_negative_rejected(self):
        with self.assertRaises(sqlite3.IntegrityError):self.pay('P',-1)
    def test_invalid_date(self):
        with self.assertRaises(ValueError):lab.snapshot(self.c,'not-a-date')
    def test_transition_expected(self):
        x=lab.transitions(self.c,'2026-02-01','2026-03-03');self.assertEqual(x['counts'][0][1],1)
    def test_transition_order(self):
        with self.assertRaises(ValueError):lab.transitions(self.c,'2026-03-03','2026-02-01')
    def test_segment_filter(self):
        self.assertEqual(lab.snapshot(self.c,'2026-03-03','Self-employed'),[])
    def test_bucket_boundaries(self):
        for d,i in [(0,0),(1,1),(30,1),(31,2),(60,2),(61,3),(90,3),(91,4)]:
            with self.subTest(d=d):self.assertEqual(lab.bucket(d),lab.BUCKETS[i])
    def test_calendar_months(self):
        self.assertEqual(lab.month_add(lab.date(2026,1,31),1),lab.date(2026,2,28))
    def test_chronology_flag(self):
        self.pay('P',1,'2025-12-31');self.assertFalse(lab.quality(self.c,'2026-03-03')['passed'])

class DemoTests(unittest.TestCase):
    def test_deterministic(self):
        a,b=lab.connect(),lab.connect();lab.seed(a);lab.seed(b);self.assertEqual(lab.snapshot(a,'2026-09-30'),lab.snapshot(b,'2026-09-30'))
    def test_cohort_age(self):
        c=lab.connect();lab.seed(c)
        for x in lab.cohort_mob(c):
            self.assertEqual(x['loans'],100);self.assertEqual(x['cutoff'][5:7],f"{int(x['cohort'][5:7])+x['mob']:02}")
    def test_export_integrity(self):
        with tempfile.TemporaryDirectory() as t:
            p=lab.build(Path(t));self.assertEqual(p['snapshots']['2026-09-30']['metrics']['loans'],600)
            self.assertNotIn('/*PAYLOAD*/',(Path(t)/'index.html').read_text())
            for d in p['snapshots'].values():self.assertTrue(d['quality']['passed'])
            manifests=json.loads((Path(t)/'manifest.json').read_text());self.assertEqual(len(manifests),8)

if __name__=='__main__':unittest.main()
