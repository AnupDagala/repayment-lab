PRAGMA foreign_keys = ON;
CREATE TABLE loans(loan_id TEXT PRIMARY KEY, originated TEXT NOT NULL, segment TEXT NOT NULL, principal_paise INTEGER NOT NULL CHECK(principal_paise>0));
CREATE TABLE installments(installment_id TEXT PRIMARY KEY, loan_id TEXT NOT NULL REFERENCES loans, due_date TEXT NOT NULL, due_paise INTEGER NOT NULL CHECK(due_paise>0));
CREATE TABLE payments(payment_id TEXT PRIMARY KEY, installment_id TEXT NOT NULL REFERENCES installments, paid_date TEXT NOT NULL, amount_paise INTEGER NOT NULL CHECK(amount_paise>0));
CREATE INDEX ix_payments_installment_date ON payments(installment_id,paid_date);
CREATE INDEX ix_installments_loan_due ON installments(loan_id,due_date);
