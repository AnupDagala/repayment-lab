-- Aggregate payments before joining: one-to-many joins must not multiply dues.
-- :as_of is a point-in-time cutoff. Future payments do not repair past snapshots.
WITH settled AS (
 SELECT installment_id, SUM(amount_paise) paid_paise FROM payments
 WHERE paid_date <= :as_of GROUP BY installment_id
), ledger AS (
 SELECT i.*, MIN(i.due_paise,COALESCE(s.paid_paise,0)) allocated_paise,
 MAX(0,i.due_paise-COALESCE(s.paid_paise,0)) remaining_paise,
 MAX(0,COALESCE(s.paid_paise,0)-i.due_paise) excess_paise
 FROM installments i LEFT JOIN settled s USING(installment_id)
)
SELECT l.loan_id,l.segment,SUBSTR(l.originated,1,7) cohort,
 SUM(g.remaining_paise) outstanding_paise,
 SUM(CASE WHEN g.due_date <= :as_of THEN g.due_paise ELSE 0 END) due_paise,
 SUM(CASE WHEN g.due_date <= :as_of THEN g.allocated_paise ELSE 0 END) collected_paise,
 SUM(CASE WHEN g.due_date < :as_of THEN g.remaining_paise ELSE 0 END) overdue_paise,
 COALESCE(MAX(CASE WHEN g.due_date < :as_of AND g.remaining_paise>0
 THEN CAST(julianday(:as_of)-julianday(g.due_date) AS INTEGER) ELSE 0 END),0) dpd,
 SUM(g.excess_paise) excess_paise
FROM loans l JOIN ledger g USING(loan_id) WHERE l.originated <= :as_of
GROUP BY l.loan_id,l.segment,cohort ORDER BY l.loan_id;
