# BI and spreadsheet handoff

Import `demo/loan_snapshot.csv` (one row per loan as of 30 September 2026). Set monetary columns to integer and IDs to text. Divide paise by 100 for INR. It already includes allocated repayments; do not join raw payments directly to this mart.

Power BI measures:

```dax
Overdue INR = SUM(loan_snapshot[overdue_paise]) / 100
Outstanding INR = SUM(loan_snapshot[outstanding_paise]) / 100
Collection Rate = DIVIDE(SUM(loan_snapshot[collected_paise]), SUM(loan_snapshot[due_paise]))
DPD30 Balance Share = DIVIDE(CALCULATE(SUM(loan_snapshot[outstanding_paise]), loan_snapshot[dpd] >= 30), SUM(loan_snapshot[outstanding_paise]))
```

Format ratios as percentages. A denominator of zero should display blank/N/A. Use segment slicers, bucket counts and loan drilldown. `demo/cohort_mob.csv` supports a cohort × MOB comparison of the exported point-in-time measures; it is not a segment-level table.

For Excel, create a pivot table with segment as rows and SUM of due/collected/overdue paise as values. Compute collection ratio from sums, not the mean of per-loan percentages. Join IDs using exact-match VLOOKUP or XLOOKUP if adding source attributes. These are handoff instructions, not a verified Excel workbook.

SQL drilldown example after opening `demo/repayment.db`: run `sql/snapshot.sql` with `:as_of='2026-09-30'`. The Python module exposes the same query through `snapshot(connection, as_of)`.
