# Navi application route — checked 5 October 2026

The official Navi careers page https://navi.com/careers links to Navi TurboHire. Searching that portal for Data Analyst returned one listing:

- Data Analyst, job code **NL-72540**
- Bangalore, Karnataka, India
- **4 positions** displayed
- Portal expiry **31 December 2026**
- Required skills: SQL, Dashboarding, data management
- Same central analytics description and 1–3 years experience requirement as the provided LinkedIn listing (4462964424)

Direct listing observed in the official portal:

https://navi.turbohire.co/job/publicjobs/odSstLbnm5OfvGxzFfsSOGE_vVxZaxTq8VToA4EXfhOUDhENpg9%2FQZSkXdYVxqpt

The listing shows **Sign in to apply**. The public page contains no public direct assessment button. The post-login assessment flow was not inspected; the claim that assessment comes first remains unverified for this vacancy. Ask the person who told you for the original assessment invitation or current recruiter-issued link, referencing NL-72540.

A four-year-old analytics hiring post by Chaitanya Khanorkar contains chaitanya.r@navi.com. Its age makes it unsuitable to describe as a current verified hiring contact. Other found recruitment posts are also years old. No recruiter emails were sent and no application was submitted.

Suggested application order: (1) official TurboHire vacancy, (2) assessment invitation verified against this vacancy, (3) a current Navi employee referral to NL-72540 with the project and resume. More aggregator submissions do not establish an assessment route.
